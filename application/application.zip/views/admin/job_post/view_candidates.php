<?php $session = $this->session->userdata('username');?>
<?php $get_animate = $this->Xin_model->get_content_animate();?>
<input type="hidden" id="job_id" value="<?php echo $this->uri->segment(4);?>" />
<div class="card <?php echo $get_animate;?>">
  <div class="card-header with-elements"> <span class="card-header-title mr-2"><strong><?php echo $this->lang->line('xin_list_all');?></strong> </span> </div>
  <div class="card-body">
    <div class="box-datatable table-responsive">
    <table id="example" class="datatables-demo table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Lengkap</th>
                <th>Jenis Kelamin</th>
                <th>Alamat</th>
                <th>Nomer Hp</th>
                <th>Tanggal Lahir</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <?php $cquery3 = $this->db2->query("SELECT *,biodata_lo.nama_depan,biodata_lo.nama_belakang,biodata_lo.jk,biodata_lo.alm_rumah,biodata_lo.no_hp,biodata_lo.tgl_l FROM lamar INNER JOIN biodata_lo ON lamar.uid = biodata_lo.uid WHERE id_job='$id'")->result(); ?>
        <tbody>
            <?php
                $no = 1;
                foreach($cquery3 as $u){ 
            ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= $u->nama_depan ?> <?= $u->nama_belakang ?></td>
                    <td><?= $u->jk ?></td>
                    <td><?= $u->alm_rumah ?></td>
                    <td><?= $u->no_hp ?></td>
                    <td><?= $u->tgl_l ?></td>
                    <td><span data-toggle="tooltip" data-placement="top" title="Panggil"><a href=""><button type="button" class="btn btn-outline-secondary btn-sm m-b-0-0 waves-effect waves-light"><i class="oi oi-cloud-download"></i></button></a></span> <span data-toggle="tooltip" data-placement="top" title="Lihat"><a href="<?php echo site_url('admin/job_candidates/read_application/');?>"><button type="button" class="btn btn-outline-secondary btn-sm m-b-0-0 waves-effect waves-light"><i class="oi oi-cloud-download"></i></button></a></span></td>
                </tr>
            <?php
                }
            ?>
        </tbody>
        
    </table>
      <script type="text/javascript">
            $(document).ready(function () {
                $('#example').DataTable();
            });
        </script>
    </div>
  </div>
</div>