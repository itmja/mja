


<?php
/* Job Candidates view
*/
?>
<?php $session = $this->session->userdata('username');?>

