
<div class="card">
  <h6 class="card-header"> <?php echo $this->lang->line('xin_org_chart_title');?> </h6>
  <div class="card-block">
    <div id="chart-container"></div>
  </div>
</div>
